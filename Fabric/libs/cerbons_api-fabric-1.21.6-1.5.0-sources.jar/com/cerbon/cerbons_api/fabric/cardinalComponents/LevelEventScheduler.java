package com.cerbon.cerbons_api.fabric.cardinalComponents;

import com.cerbon.cerbons_api.api.general.event.EventScheduler;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1937;
import org.ladysnake.cca.api.v3.component.tick.ClientTickingComponent;
import org.ladysnake.cca.api.v3.component.tick.ServerTickingComponent;

public class LevelEventScheduler implements ILevelEventSchedulerComponent, ServerTickingComponent, ClientTickingComponent {
    private final EventScheduler eventScheduler = new EventScheduler();

    public LevelEventScheduler(class_1937 level) {}

    @Override
    public EventScheduler get() {
        return eventScheduler;
    }

    @Override
    public void clientTick() {
        eventScheduler.updateEvents();
    }

    @Override
    public void serverTick() {
        eventScheduler.updateEvents();
    }

    @Override
    public void readData(class_11368 readView) {
        // NO-OP
    }

    @Override
    public void writeData(class_11372 writeView) {
        // NO-OP
    }
}
