package com.cerbon.cerbons_api.fabric.registry;

import com.cerbon.cerbons_api.api.registry.RegistryEntries;
import com.cerbon.cerbons_api.api.registry.RegistryEntry;
import com.cerbon.cerbons_api.api.registry.ResourcefulRegistry;
import java.util.Collection;
import java.util.function.Supplier;
import net.minecraft.class_2378;
import net.minecraft.class_2960;

public class FabricResourcefulRegistry<T> implements ResourcefulRegistry<T> {
    private final RegistryEntries<T> entries = new RegistryEntries<>();
    private final class_2378<T> registry;
    private final String id;

    public FabricResourcefulRegistry(class_2378<T> registry, String id) {
        this.registry = registry;
        this.id = id;
    }

    @Override
    public <I extends T> RegistryEntry<I> register(String id, Supplier<I> supplier) {
        return entries.add(FabricRegistryEntry.of(this.registry, class_2960.method_60655(this.id, id), supplier));
    }

    @Override
    public Collection<RegistryEntry<T>> getEntries() {
        return this.entries.getEntries();
    }

    @Override
    public void register() {
        // NO-OP
    }
}
