package com.cerbon.cerbons_api.fabric.registry;

import com.cerbon.cerbons_api.api.registry.RegistryEntry;
import java.util.function.Supplier;
import net.minecraft.class_2378;
import net.minecraft.class_2960;

public class FabricRegistryEntry<T> implements RegistryEntry<T> {
    private final class_2960 id;
    private final T value;

    private FabricRegistryEntry(class_2960 id, T value) {
        this.id = id;
        this.value = value;
    }

    public static <T, I extends T> FabricRegistryEntry<I> of(class_2378<T> registry, class_2960 id, Supplier<I> supplier) {
        return new FabricRegistryEntry<>(id, class_2378.method_10230(registry, id, supplier.get()));
    }

    @Override
    public T get() {
        return this.value;
    }

    @Override
    public class_2960 getId() {
        return this.id;
    }
}
