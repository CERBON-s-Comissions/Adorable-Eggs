package com.cerbon.cerbons_api.fabric.platform;

import com.cerbon.cerbons_api.platform.services.IMenuTypeHelper;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3908;
import net.minecraft.class_3917;
import net.minecraft.class_7701;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.function.Consumer;
import java.util.function.Function;

public class FabricMenuTypeHelper implements IMenuTypeHelper {

    @Override
    public <T extends class_1703> class_3917<T> registerSimpleMenuType(SimpleMenuSupplier<T> factory) {
        return new class_3917<>(factory::create, class_7701.field_40183);
    }

    @Override
    public <T extends class_1703, D> class_3917<T> registerExtendedMenuType(ExtendedMenuSupplier<T, D> factory, class_9139<? super class_9129, D> extraDataFabric) {
        if (extraDataFabric == null)
            throw new IllegalArgumentException("extraDataFabric must not be null for Fabric environment");

        return new ExtendedScreenHandlerType<>((windowId, playerInv, extraData) -> factory.create(windowId, playerInv, extraData, null), extraDataFabric);
    }

    @Override
    public <D> void openExtendedMenu(class_1657 player, class_3908 menuProvider, Function<class_3222, D> extraDataFabric, Consumer<class_2540> extraDataForge) {
        player.method_17355(new ExtendedScreenHandlerFactory<>() {

            @Nullable
            @Override
            public class_1703 createMenu(int windowId, class_1661 playerInv, class_1657 player) {
                return menuProvider.createMenu(windowId, playerInv, player);
            }

            @Override
            public @NotNull class_2561 method_5476() {
                return menuProvider.method_5476();
            }

            @Override
            public D getScreenOpeningData(class_3222 serverPlayer) {
                return extraDataFabric.apply(serverPlayer);
            }
        });
    }
}
