package com.cerbon.cerbons_api.fabric.platform;

import com.cerbon.cerbons_api.api.general.event.EventScheduler;
import com.cerbon.cerbons_api.fabric.cardinalComponents.Components;
import com.cerbon.cerbons_api.platform.services.ICapabilityHelper;
import net.minecraft.class_1937;

public class FabricCapabilityHelper implements ICapabilityHelper {

    @Override
    public EventScheduler getLevelEventScheduler(class_1937 level) {
        return Components.getLevelEventScheduler(level);
    }
}
