package com.cerbon.cerbons_api.api.static_utilities;

import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.Vec3;

public class VecUtils {
    public static final Vec3 xAxis = new Vec3(1.0, 0.0, 0.0);
    public static final Vec3 yAxis = new Vec3(0.0, 1.0, 0.0);
    public static final Vec3 zAxis = new Vec3(0.0, 0.0, 1.0);
    public static final Vec3 unit = new Vec3(1.0, 1.0, 1.0);

    public static Vec3 yOffset(Vec3 vec, double i) {
        return vec.add(0.0, i, 0.0);
    }

    public static Vec3 planeProject(Vec3 vec, Vec3 planeVector) {
        return vec.subtract(planeVector.scale(vec.dot(planeVector)));
    }

    public static Vec3 asVec3(BlockPos blockPos) {
        return new Vec3(blockPos.getX(), blockPos.getY(), blockPos.getZ());
    }

    public static Vec3 negateServer(Vec3 vec) {
        return vec.scale(-1.0);
    }

    public static Vec3 coerceAtLeast(Vec3 vec1, Vec3 vec2) {
        return new Vec3(Math.max(vec1.x(), vec2.x()), Math.max(vec1.y(), vec2.y()), Math.max(vec1.z(), vec2.z()));
    }

    public static Vec3 coerceAtMost(Vec3 vec1, Vec3 vec2) {
        return new Vec3(Math.min(vec1.x(), vec2.x()), Math.min(vec1.y(), vec2.y()), Math.min(vec1.z(), vec2.z()));
    }

    // http://www.java-gaming.org/index.php/topic,28253
    // https://www.omnicalculator.com/math/angle-between-two-vectors#angle-between-two-vectors-formulas
    public static double unsignedAngle(Vec3 vec, Vec3 b) {
        double dot = vec.dot(b);
        double lengths = vec.length() * b.length();

        if (lengths == 0.0)
            return 0.0;

        double cos = Math.max(-1.0, Math.min(1.0, dot / lengths));
        return Math.toDegrees(Math.acos(cos));
    }

    /**
     * Rotate a vector around an axis by given degrees <a href="https://stackoverflow.com/questions/31225062/rotating-a-vector-by-angle-and-axis-in-java">Rotating a vector by angle and axis - StackOverflow</a>
     */
    public static Vec3 rotateVector(Vec3 vec, Vec3 axis, double degrees) {
        double theta = Math.toRadians(degrees);
        Vec3 normedAxis = axis.normalize();
        double x = vec.x();
        double y = vec.y();
        double z = vec.z();
        double u = normedAxis.x();
        double v = normedAxis.y();
        double w = normedAxis.z();
        double v1 = u * x + v * y + w * z;
        double xPrime = u * v1 * (1.0 - Math.cos(theta)) + x * Math.cos(theta) + (-w * y + v * z) * Math.sin(theta);
        double yPrime = v * v1 * (1.0 - Math.cos(theta)) + y * Math.cos(theta) + (w * x - u * z) * Math.sin(theta);
        double zPrime = w * v1 * (1.0 - Math.cos(theta)) + z * Math.cos(theta) + (-v * x + u * y) * Math.sin(theta);
        return new Vec3(xPrime, yPrime, zPrime);
    }
}
