package com.cerbon.cerbons_api.packet.custom;

import com.cerbon.cerbons_api.api.multipart_entities.client.PlayerInteractMultipartEntity;
import com.cerbon.cerbons_api.api.multipart_entities.entity.MultipartAwareEntity;
import com.cerbon.cerbons_api.api.network.data.PacketContext;
import com.cerbon.cerbons_api.api.network.data.Side;
import com.cerbon.cerbons_api.util.Constants;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

public class MultipartEntityInteractionC2SPacket {
    public static final class_2960 CHANNEL = class_2960.method_60655(Constants.MOD_ID, "multipart_entity_interaction");
    public static final class_9139<class_2540, MultipartEntityInteractionC2SPacket> STREAM_CODEC = class_9139.method_56438(MultipartEntityInteractionC2SPacket::write, MultipartEntityInteractionC2SPacket::new);

    private final int entityId;
    private final String part;
    private final class_1268 hand;
    private final boolean isSneaking;
    private final PlayerInteractMultipartEntity.InteractionType interactionType;

    public MultipartEntityInteractionC2SPacket(int entityId, String part, class_1268 hand, boolean isSneaking, PlayerInteractMultipartEntity.InteractionType interactionType) {
        this.entityId = entityId;
        this.part = part;
        this.hand = hand;
        this.isSneaking = isSneaking;
        this.interactionType = interactionType;
    }

    public MultipartEntityInteractionC2SPacket(class_2540 buf) {
        this.entityId = buf.readInt();
        this.part = buf.method_10800(32767);
        this.hand = buf.method_10818(class_1268.class);
        this.isSneaking = buf.readBoolean();
        this.interactionType = buf.method_10818(PlayerInteractMultipartEntity.InteractionType.class);
    }

    public void write(class_2540 buf) {
        buf.method_53002(entityId);
        buf.method_10814(part);
        buf.method_10817(hand);
        buf.method_52964(isSneaking);
        buf.method_10817(interactionType);
    }

    public static void handle(PacketContext<MultipartEntityInteractionC2SPacket> ctx) {
        if (ctx.side().equals(Side.CLIENT) || ctx.sender() == null) return;

        class_3222 serverPlayer = ctx.sender();
        MultipartEntityInteractionC2SPacket packet = ctx.message();

        class_3218 serverLevel = serverPlayer.method_51469();

        serverPlayer.method_5660(packet.isSneaking);
        class_1297 entity = serverLevel.method_8469(packet.entityId);
        if (entity == null) return;

        switch (packet.interactionType) {
            case INTERACT -> entity.method_5688(serverPlayer, packet.hand);
            case ATTACK -> setNextDamagedPart(serverPlayer, entity, packet.part);
            default -> throw new RuntimeException();
        }
    }

    private static void setNextDamagedPart(class_3222 serverPlayer, class_1297 entity, String part) {
        if (entity instanceof MultipartAwareEntity multipartAwareEntity)
            multipartAwareEntity.setNextDamagedPart(part);

        serverPlayer.method_7324(entity);
    }

    public static class_8710.class_9154<class_8710> type() {
        return new class_8710.class_9154<>(CHANNEL);
    }
}
