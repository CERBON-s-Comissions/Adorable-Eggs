package com.cerbon.cerbons_api.mixin.multipart_entities.client;

import com.cerbon.cerbons_api.api.multipart_entities.util.CompoundOrientedBox;
import com.cerbon.cerbons_api.api.multipart_entities.util.OrientedBox;
import com.google.common.collect.ImmutableList;
import net.minecraft.class_10932;
import net.minecraft.class_1297;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_897;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_897.class)
public class EntityRendererMixin {

    //TODO: I have no idea if this will work. Probably not. I will find out soon
    @Inject(method = "extractAdditionalHitboxes", at = @At("TAIL"))
    private <T extends class_1297> void createOrientedBoxesRenderStates(T entity, ImmutableList.Builder<class_10932> hitboxes, float partialTick, CallbackInfo ci) {
        class_238 box = entity.method_5829();
        if (!(box instanceof CompoundOrientedBox compound)) return;

        for (OrientedBox orientedBox : compound) {
            class_243 center   = orientedBox.getCenter();
            class_243 halfSize = orientedBox.getHalfExtents();

            double minX = center.field_1352 - halfSize.field_1352;
            double minY = center.field_1351 - halfSize.field_1351;
            double minZ = center.field_1350 - halfSize.field_1350;
            double maxX = center.field_1352 + halfSize.field_1352;
            double maxY = center.field_1351 + halfSize.field_1351;
            double maxZ = center.field_1350 + halfSize.field_1350;

            float x0 = (float) (minX - entity.method_23317());
            float y0 = (float) (minY - entity.method_23318());
            float z0 = (float) (minZ - entity.method_23321());
            float x1 = (float) (maxX - entity.method_23317());
            float y1 = (float) (maxY - entity.method_23318());
            float z1 = (float) (maxZ - entity.method_23321());

            hitboxes.add(new class_10932(
                    x0, y0, z0,
                    x1, y1, z1,
                    0f, 0f, 0f,
                    0f, 0f, 1f
            ));
        }

        compound.toVoxelShape().method_1089((minX, minY, minZ, maxX, maxY, maxZ) -> {
            float x0 = (float) (minX - entity.method_23317());
            float y0 = (float) (minY - entity.method_23318());
            float z0 = (float) (minZ - entity.method_23321());
            float x1 = (float) (maxX - entity.method_23317());
            float y1 = (float) (maxY - entity.method_23318());
            float z1 = (float) (maxZ - entity.method_23321());

            hitboxes.add(new class_10932(
                    x0, y0, z0,
                    x1, y1, z1,
                    0f, 0f, 0f,
                    0f, 1f, 0f
            ));
        });
    }

//    @Inject(method = "renderHitbox", at = @At("RETURN"))
//    private static void drawOrientedBoxes(PoseStack poseStack, VertexConsumer buffer, HitboxRenderState hitbox, CallbackInfo ci) {
//        final AABB box = entity.getBoundingBox();
//
//        if (box instanceof final CompoundOrientedBox compoundOrientedBox) {
//            poseStack.pushPose();
//            poseStack.translate(-entity.getX(), -entity.getY(), -entity.getZ());
//
//            for (final OrientedBox orientedBox : compoundOrientedBox) {
//                poseStack.pushPose();
//                final Vec3 center = orientedBox.getCenter();
//                poseStack.translate(center.x, center.y, center.z);
//                poseStack.mulPose(orientedBox.getRotation().toFloatQuat());
//                ShapeRenderer.renderLineBox(poseStack, buffer, orientedBox.getExtents(), 0, 0, 1, 1);
//                poseStack.popPose();
//            }
//
//            compoundOrientedBox.toVoxelShape().forAllBoxes((minX, minY, minZ, maxX, maxY, maxZ) -> ShapeRenderer.renderLineBox(poseStack, buffer, minX, minY, minZ, maxX, maxY, maxZ, 0, 1, 0, 1f));
//            poseStack.popPose();
//        }
//    }
}
