package com.cerbon.cerbons_api.mixin.multipart_entities;

import com.cerbon.cerbons_api.api.multipart_entities.entity.MultipartAwareEntity;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1676;
import net.minecraft.class_1937;
import net.minecraft.class_239;
import net.minecraft.class_3966;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;


@Mixin(class_1676.class)
public abstract class ProjectileMixin extends class_1297 {

    public ProjectileMixin(class_1299<?> type, class_1937 level) {
        super(type, level);
    }

    @Inject(method = "onHit", at = @At("HEAD"))
    private void onCollision(class_239 hitResult, CallbackInfo ci) {
        class_239.class_240 type = hitResult.method_17783();

        if (type == class_239.class_240.field_1331 && hitResult instanceof class_3966 entityHitResult) {
            class_1297 target = entityHitResult.method_17782();

            if (target instanceof MultipartAwareEntity multipartAwareEntity) {
                String nextDamagedPart = multipartAwareEntity.getBounds().raycast(method_19538(), method_19538().method_1019(method_18798()));
                multipartAwareEntity.setNextDamagedPart(nextDamagedPart);
            }
        }
    }
}
