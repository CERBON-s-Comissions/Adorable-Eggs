package com.cerbon.cerbons_api.mixin.multipart_entities;

import it.unimi.dsi.fastutil.doubles.DoubleList;
import net.minecraft.class_245;
import net.minecraft.class_251;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_245.class)
public interface InvokerArrayVoxelShape {

    @Invoker(value = "<init>")
    static class_245 init(final class_251 shape, final DoubleList xPoints, final DoubleList yPoints, final DoubleList zPoints) {
        throw new AssertionError();
    }
}
