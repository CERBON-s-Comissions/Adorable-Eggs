package com.cerbon.cerbons_api.mixin.multipart_entities;

import com.cerbon.cerbons_api.api.multipart_entities.util.CompoundOrientedBox;
import net.minecraft.class_238;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_238.class)
public class AABBMixin {

    @Inject(method = "intersects(Lnet/minecraft/world/phys/AABB;)Z", at = @At("HEAD"), cancellable = true)
    private void hook(final class_238 box, final CallbackInfoReturnable<Boolean> cir) {
        if (box instanceof CompoundOrientedBox)
            cir.setReturnValue(box.method_994((class_238) (Object) this));
    }
}
