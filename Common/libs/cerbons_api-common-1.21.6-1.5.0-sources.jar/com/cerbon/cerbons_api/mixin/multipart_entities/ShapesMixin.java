package com.cerbon.cerbons_api.mixin.multipart_entities;

import com.cerbon.cerbons_api.api.multipart_entities.util.CompoundOrientedBox;
import net.minecraft.class_238;
import net.minecraft.class_259;
import net.minecraft.class_265;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_259.class)
public class ShapesMixin {

    @Inject(method = "create(Lnet/minecraft/world/phys/AABB;)Lnet/minecraft/world/phys/shapes/VoxelShape;", at = @At("HEAD"), cancellable = true)
    private static void hook(final class_238 box, final CallbackInfoReturnable<class_265> cir) {
        if (box instanceof CompoundOrientedBox compoundOrientedBox)
            cir.setReturnValue(compoundOrientedBox.toVoxelShape());
    }
}
