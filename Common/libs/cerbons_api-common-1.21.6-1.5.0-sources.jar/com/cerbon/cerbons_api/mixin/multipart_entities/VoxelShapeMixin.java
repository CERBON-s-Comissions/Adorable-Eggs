package com.cerbon.cerbons_api.mixin.multipart_entities;

import com.cerbon.cerbons_api.api.multipart_entities.util.CompoundOrientedBox;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_265;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_265.class)
public class VoxelShapeMixin {

    @Inject(method = "collide", at = @At("HEAD"), cancellable = true)
    private void hook(final class_2350.class_2351 axis, final class_238 box, final double maxDist, final CallbackInfoReturnable<Double> cir) {
        if (box instanceof CompoundOrientedBox compoundOrientedBox)
            cir.setReturnValue(compoundOrientedBox.calculateMaxDistance(axis, (class_265) (Object) this, maxDist));
    }
}
