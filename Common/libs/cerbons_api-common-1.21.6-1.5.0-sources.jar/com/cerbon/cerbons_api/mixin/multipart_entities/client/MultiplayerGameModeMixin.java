package com.cerbon.cerbons_api.mixin.multipart_entities.client;

import com.cerbon.cerbons_api.api.multipart_entities.client.PlayerInteractMultipartEntity;
import com.cerbon.cerbons_api.api.multipart_entities.entity.MultipartAwareEntity;
import com.cerbon.cerbons_api.api.network.Dispatcher;
import com.cerbon.cerbons_api.packet.custom.MultipartEntityInteractionC2SPacket;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1934;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_5134;
import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_636.class)
public abstract class MultiplayerGameModeMixin {

    @Shadow private class_1934 localPlayerMode;

    @Shadow protected abstract void ensureHasSentCarriedItem();

    @Inject(method = "attack", at = @At("HEAD"), cancellable = true)
    private void attackHook(final class_1657 player, final class_1297 target, final CallbackInfo ci) {
        if (target instanceof MultipartAwareEntity multipartAwareEntity) {
            ensureHasSentCarriedItem();

            class_310 client = class_310.method_1551();
            final class_243 pos = client.field_1719.method_5836(client.method_61966().method_60636());
            final class_243 dir = client.field_1719.method_5828(client.method_61966().method_60636());
            final double reach = client.field_1724.method_45325(class_5134.field_47759);
            String part = multipartAwareEntity.getBounds().raycast(pos, pos.method_1019(dir.method_1021(reach)));
            if (part == null) return;

            Dispatcher.sendToServer(new MultipartEntityInteractionC2SPacket(target.method_5628(), part, class_1268.field_5808, client.field_1719.method_5715(), PlayerInteractMultipartEntity.InteractionType.ATTACK));

            if (localPlayerMode == class_1934.field_9219) return;
            multipartAwareEntity.setNextDamagedPart(part);
            player.method_7324(target);
            player.method_7350();

            ci.cancel();
        }
    }

    @Inject(method = "interact", at = @At("HEAD"), cancellable = true)
    private void interactHook(final class_1657 player, final class_1297 entity, final class_1268 hand, final CallbackInfoReturnable<class_1269> cir) {
        if (entity instanceof MultipartAwareEntity multipartAwareEntity) {
            ensureHasSentCarriedItem();

            class_310 client = class_310.method_1551();
            final class_243 pos = client.field_1719.method_5836(client.method_61966().method_60636());
            final class_243 dir = client.field_1719.method_5828(client.method_61966().method_60636());
            final double reach = client.field_1724.method_45325(class_5134.field_47759);;
            String part = multipartAwareEntity.getBounds().raycast(pos, pos.method_1019(dir.method_1021(reach)));
            if (part == null) return;

            Dispatcher.sendToServer(new MultipartEntityInteractionC2SPacket(entity.method_5628(), part, hand, client.field_1719.method_5715(), PlayerInteractMultipartEntity.InteractionType.INTERACT));

            if (localPlayerMode != class_1934.field_9219)
                cir.setReturnValue(multipartAwareEntity.interact(player, hand, part));

            cir.setReturnValue(class_1269.field_5811);
        }
    }
}
