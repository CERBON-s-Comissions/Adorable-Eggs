package com.cerbon.cerbons_api.platform.services;

import com.cerbon.cerbons_api.api.registry.ResourcefulRegistry;
import net.minecraft.class_2378;

public interface IRegistryHelper {

    <T> ResourcefulRegistry<T> create(class_2378<T> registry, String id);
}
