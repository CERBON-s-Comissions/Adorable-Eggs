package com.cerbon.cerbons_api.platform.services;

import org.jetbrains.annotations.Nullable;

import java.util.function.Consumer;
import java.util.function.Function;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_2540;
import net.minecraft.class_3222;
import net.minecraft.class_3908;
import net.minecraft.class_3917;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public interface IMenuTypeHelper {

    <T extends class_1703> class_3917<T> registerSimpleMenuType(SimpleMenuSupplier<T> factory);
    <T extends class_1703, D> class_3917<T> registerExtendedMenuType(ExtendedMenuSupplier<T, D> factory, class_9139<? super class_9129, D> extraDataFabric);

    <D> void openExtendedMenu(class_1657 player, class_3908 menuProvider, Function<class_3222, D> extraDataFabric, Consumer<class_2540> extraDataForge);

    @FunctionalInterface
    interface SimpleMenuSupplier<T extends class_1703> {
        T create(int windowId, class_1661 playerInv);
    }

    @FunctionalInterface
    interface ExtendedMenuSupplier<T extends class_1703, D> {
        T create(int windowId, class_1661 playerInv, @Nullable D extraDataFabric, @Nullable class_2540 extraDataForge);
    }
}
