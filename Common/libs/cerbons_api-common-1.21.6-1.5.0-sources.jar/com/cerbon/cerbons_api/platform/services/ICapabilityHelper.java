package com.cerbon.cerbons_api.platform.services;

import com.cerbon.cerbons_api.api.general.event.EventScheduler;
import net.minecraft.class_1937;

public interface ICapabilityHelper {

    EventScheduler getLevelEventScheduler(class_1937 level);
}
