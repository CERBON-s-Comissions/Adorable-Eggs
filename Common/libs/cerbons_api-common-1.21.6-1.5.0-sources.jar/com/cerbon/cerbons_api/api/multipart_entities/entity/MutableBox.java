package com.cerbon.cerbons_api.api.multipart_entities.entity;

import net.minecraft.class_238;

public final class MutableBox {
    private class_238 box;

    public MutableBox(class_238 box) {
        this.box = box;
    }

    public class_238 getBox() {
        return box;
    }

    public void setBox(class_238 box) {
        this.box = box;
    }
}
