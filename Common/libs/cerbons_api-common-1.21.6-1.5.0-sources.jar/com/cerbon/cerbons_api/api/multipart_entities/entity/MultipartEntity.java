package com.cerbon.cerbons_api.api.multipart_entities.entity;

import com.cerbon.cerbons_api.api.multipart_entities.util.CompoundOrientedBox;
import net.minecraft.class_238;

public interface MultipartEntity {
    CompoundOrientedBox getCompoundBoundingBox(class_238 bounds);
}
