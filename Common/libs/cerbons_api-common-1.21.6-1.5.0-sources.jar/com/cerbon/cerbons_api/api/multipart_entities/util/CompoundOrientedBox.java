package com.cerbon.cerbons_api.api.multipart_entities.util;

import com.cerbon.cerbons_api.api.multipart_entities.entity.MutableBox;
import com.cerbon.cerbons_api.mixin.multipart_entities.InvokerArrayVoxelShape;
import com.google.common.collect.Iterators;
import it.unimi.dsi.fastutil.doubles.DoubleArrayList;
import it.unimi.dsi.fastutil.doubles.DoubleList;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_244;
import net.minecraft.class_259;
import net.minecraft.class_265;

public final class CompoundOrientedBox extends class_238 implements Iterable<OrientedBox> {
    private final Collection<OrientedBox> boxes;
    private class_265 cached;
    private final @Nullable MutableBox overrideBox;

    public CompoundOrientedBox(final class_238 bounds, final Collection<OrientedBox> boxes, MutableBox overrideBox) {
        this(bounds.field_1323, bounds.field_1322, bounds.field_1321, bounds.field_1320, bounds.field_1325, bounds.field_1324, boxes, overrideBox);
    }

    public CompoundOrientedBox(final double minX, final double minY, final double minZ, final double maxX, final double maxY, final double maxZ, final Collection<OrientedBox> boxes, @Nullable MutableBox overrideBox) {
        super(minX, minY, minZ, maxX, maxY, maxZ);
        this.boxes = boxes;
        this.overrideBox = overrideBox;
    }

    private CompoundOrientedBox(final double minX, final double minY, final double minZ, final double maxX, final double maxY, final double maxZ, final Collection<OrientedBox> boxes, final class_265 cached, @Nullable MutableBox overrideBox) {
        super(minX, minY, minZ, maxX, maxY, maxZ);
        this.boxes = boxes;
        this.cached = cached;
        this.overrideBox = overrideBox;
    }

    @Override
    public @NotNull class_238 method_1009(final double x, final double y, final double z) {
        final List<OrientedBox> orientedBoxes = new ObjectArrayList<>(boxes.size());
        for (final OrientedBox box : boxes)
            orientedBoxes.add(box.expand(x,y,z));

        MutableBox overrideBox = null;
        if(this.overrideBox != null)
            overrideBox = new MutableBox(this.overrideBox.getBox().method_1009(x, y, z));

        if (cached != null) {
            return new CompoundOrientedBox(field_1323 - x, field_1322 - y, field_1321 - z, field_1320 + x, field_1325 + y, field_1324 + z, orientedBoxes, cached.method_1096(x, y, z), overrideBox);
        }
        return new CompoundOrientedBox(field_1323 - x, field_1322 - y, field_1321 - z, field_1320 + x, field_1325 + y, field_1324 + z, orientedBoxes, overrideBox);
    }

    @Override
    public @NotNull class_238 method_989(final double x, final double y, final double z) {
        final List<OrientedBox> orientedBoxes = new ObjectArrayList<>(boxes.size());
        for (final OrientedBox box : boxes)
            orientedBoxes.add(box.offset(x, y, z));

        MutableBox overrideBox = null;
        if(this.overrideBox != null)
            overrideBox = new MutableBox(this.overrideBox.getBox().method_989(x, y, z));

        if (cached != null) {
            return new CompoundOrientedBox(field_1323 + x, field_1322 + y, field_1321 + z, field_1320 + x, field_1325 + y, field_1324 + z, orientedBoxes, cached.method_1096(x, y, z), overrideBox);
        }
        return new CompoundOrientedBox(field_1323 + x, field_1322 + y, field_1321 + z, field_1320 + x, field_1325 + y, field_1324 + z, orientedBoxes, overrideBox);
    }

    @Override
    public @NotNull class_238 method_996(final class_2338 blockPos) {
        return method_989(blockPos.method_10263(), blockPos.method_10264(), blockPos.method_10260());
    }

    @Override
    public @NotNull Optional<class_243> method_992(final @NotNull class_243 min, final @NotNull class_243 max) {
        double t = Double.MAX_VALUE;
        for (final OrientedBox box : boxes) {
            final double tmp = box.raycast(min, max);
            if (tmp != -1)
                t = Math.min(t, tmp);
        }
        if (t != Double.MAX_VALUE) {
            final double d = max.field_1352 - min.field_1352;
            final double e = max.field_1351 - min.field_1351;
            final double f = max.field_1350 - min.field_1350;
            return Optional.of(min.method_1031(t * d, t * e, t * f));
        }
        return Optional.empty();
    }

    @NotNull
    @Override
    public Iterator<OrientedBox> iterator() {
        return Iterators.unmodifiableIterator(boxes.iterator());
    }

    @Override
    public boolean method_1003(final double minX, final double minY, final double minZ, final double maxX, final double maxY, final double maxZ) {
        return method_994(new class_238(minX, minY, minZ, maxX, maxY, maxZ));
    }

    @Override
    public boolean method_994(final @NotNull class_238 box) {
        final class_243[] vertices = OrientedBox.getVertices(box);
        for (final OrientedBox orientedBox : boxes) {
            if (orientedBox.intersects(vertices))
                return true;
        }
        return false;
    }

    public class_265 toVoxelShape() {
        if (cached != null) {
            return cached;
        }
        if(overrideBox != null) {
            cached = class_259.method_1078(overrideBox.getBox());
            return cached;
        }
        final double minX = method_1001(class_2350.class_2351.field_11048) + 0.0001;
        final double minY = method_1001(class_2350.class_2351.field_11052) + 0.0001;
        final double minZ = method_1001(class_2350.class_2351.field_11051) + 0.0001;

        final double deltaX = method_990(class_2350.class_2351.field_11048) - minX;
        final double deltaY = method_990(class_2350.class_2351.field_11052) - minY;
        final double deltaZ = method_990(class_2350.class_2351.field_11051) - minZ;
        double resolution = 4.0;
        final int xResolution = (int) Math.ceil(deltaX * resolution + 0.0001);
        final int yResolution = (int) Math.ceil(deltaY * resolution + 0.0001);
        final int zResolution = (int) Math.ceil(deltaZ * resolution + 0.0001);

        final class_244 bitSet = new class_244(xResolution, yResolution, zResolution);
        for (int i = 0; i < xResolution; i++) {
            final double x = minX + i / resolution;
            for (int j = 0; j < zResolution; j++) {
                final double z = minZ + j / resolution;
                for (int k = 0; k < yResolution; k++) {
                    final double y = minY + k / resolution;
                    final class_238 box = new class_238(x, y, z, x + 0.9999 / xResolution, y + 0.9999 / yResolution, z + 0.9999 / zResolution);
                    if (method_994(box))
                        bitSet.method_1049(i, k, j);
                }
            }
        }
        final DoubleList xPoints = new DoubleArrayList(xResolution + 1);
        for (int i = 0; i < xResolution + 1; i++)
            xPoints.add(minX + i / resolution);

        final DoubleList yPoints = new DoubleArrayList(yResolution + 1);
        for (int i = 0; i < yResolution + 1; i++)
            yPoints.add(minY + i / resolution);

        final DoubleList zPoints = new DoubleArrayList(zResolution + 1);
        for (int i = 0; i < zResolution + 1; i++)
            zPoints.add(minZ + i / resolution);

        return cached = InvokerArrayVoxelShape.init(bitSet, xPoints, yPoints, zPoints);
    }

    @Override
    public boolean method_1008(final double x, final double y, final double z) {
        for (final OrientedBox box : boxes) {
            if (box.contains(x, y, z))
                return true;
        }
        return false;
    }

    public CompoundOrientedBox withBounds(final class_238 bounds) {
        return new CompoundOrientedBox(bounds, new ObjectArrayList<>(boxes), overrideBox);
    }

    public double calculateMaxDistance(final class_2350.class_2351 axis, final class_265 voxelShape, double maxDist) {
        for (final class_238 boundingBox : toVoxelShape().method_1090()) {
            maxDist = voxelShape.method_1108(axis, boundingBox, maxDist);
            if (Math.abs(maxDist) < 0.0001)
                return 0;
        }
        return maxDist;
    }
}
