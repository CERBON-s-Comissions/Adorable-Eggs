package com.cerbon.cerbons_api.api.multipart_entities.entity;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import org.jetbrains.annotations.Nullable;

/**
 * Should be implemented by entities who want to know what part of them was attacked or interacted
 */
public interface MultipartAwareEntity extends MultipartEntity {
    /**
     * @return Entity bounds as shown in the example in {@link MultipartEntity}
     */
    EntityBounds getBounds();

    void onSetPos(final double x, final double y, final double z);

    /**
     * This is an ugly hack to not interfere with the vanilla damage logic.
     * This will be called right before {@link class_1297#method_64419(class_1282, float)} is called, the part should be stored until then
     * and reset to null after {@link class_1297#method_64419(class_1282, float)} is called.
     * A part of null indicates a damage not done by entity, for example, suffocation, void damage, etc.
     *
     * @param part The part hit by the attacker, may be null
     */
    void setNextDamagedPart(@Nullable String part);

    /**
     * @param entity The entity interacting with this
     * @param hand   The hand the entity is using
     * @param part   The part it is interacting with, should not be null
     * @return Same as vanilla interact
     */
    default class_1269 interact(final class_1297 entity, final class_1268 hand, final String part) {
        return class_1269.field_5811;
    }
}
