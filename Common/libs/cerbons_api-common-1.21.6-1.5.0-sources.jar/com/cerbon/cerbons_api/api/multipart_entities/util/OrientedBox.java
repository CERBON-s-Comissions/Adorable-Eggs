package com.cerbon.cerbons_api.api.multipart_entities.util;

import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import org.jetbrains.annotations.Nullable;

public final class OrientedBox {
    private final class_243 center;
    private final class_243 halfExtents;
    private final QuaternionD rotation;
    private class_238 extents;
    private Matrix3d matrix;
    private Matrix3d inverse;
    private class_243[] vertices;
    private class_243[] basis;

    public OrientedBox(final class_238 box) {
        center = box.method_1005();
        halfExtents = new class_243(box.method_17939() / 2, box.method_17940() / 2, box.method_17941() / 2);
        rotation = QuaternionD.IDENTITY;
    }

    public OrientedBox(final class_243 center, final class_243 halfExtents, final QuaternionD rotation) {
        this.center = center;
        this.halfExtents = halfExtents;
        this.rotation = rotation;
    }

    public OrientedBox(final double minX, final double minY, final double minZ, final double maxX, final double maxY, final double maxZ, final QuaternionD rotation) {
        center = new class_243((minX + maxX) / 2, (minY + maxY) / 2, (minZ + maxZ) / 2);
        halfExtents = new class_243((maxX - minX) / 2, (maxY - minY) / 2, (maxZ - minZ) / 2);
        this.rotation = rotation;
    }

    private OrientedBox(final class_243 center, final class_243 halfExtents, final QuaternionD rotation, final Matrix3d matrix, final Matrix3d inverse, final class_243[] basis) {
        this.center = center;
        this.halfExtents = halfExtents;
        this.rotation = rotation;
        this.matrix = matrix;
        this.inverse = inverse;
        this.basis = basis;
    }

    public Matrix3d getMatrix() {
        if (matrix == null) {
            matrix = new Matrix3d(rotation);
        }
        return matrix;
    }

    public Matrix3d getInverse() {
        if (inverse == null) {
            inverse = getMatrix().invert();
        }
        return inverse;
    }

    public class_238 getExtents() {
        if (extents == null) {
            extents = new class_238(halfExtents.method_18805(-1, -1, -1), halfExtents);
        }
        return extents;
    }

    public class_243[] getBasis() {
        if (basis == null) {
            basis = matrix.getBasis();
        }
        return basis;
    }

    public OrientedBox rotate(final QuaternionD quaternion) {
        if (QuaternionD.IDENTITY.equals(quaternion)) {
            return this;
        }
        return new OrientedBox(center, halfExtents, rotation.hamiltonProduct(quaternion));
    }

    public OrientedBox translate(final double x, final double y, final double z) {
        if (x == 0 && y == 0 && z == 0) {
            return this;
        }
        final Matrix3d matrix = getMatrix();
        final double transX = matrix.transformX(x, y, z);
        final double transY = matrix.transformY(x, y, z);
        final double transZ = matrix.transformZ(x, y, z);
        return new OrientedBox(center.method_1031(transX, transY, transZ), halfExtents, rotation, matrix, inverse, basis);
    }

    public OrientedBox transform(final double x, final double y, final double z, final double pivotX, final double pivotY, final double pivotZ, final QuaternionD quaternion) {
        final class_243 vec = getMatrix().transform(x - pivotX, y - pivotY, z - pivotZ);
        final boolean bl = quaternion.equals(QuaternionD.IDENTITY);
        return new OrientedBox(center.method_1019(vec), halfExtents, rotation.hamiltonProduct(quaternion), bl ? matrix : null, bl ? inverse : null, bl ? basis : null).translate(pivotX, pivotY, pivotZ);
    }

    public QuaternionD getRotation() {
        return rotation;
    }

    public class_243 getCenter() {
        return center;
    }

    public class_243 getHalfExtents() {
        return halfExtents;
    }

    public OrientedBox offset(final double x, final double y, final double z) {
        return new OrientedBox(center.method_1031(x, y, z), halfExtents, rotation, matrix, inverse, basis);
    }

    private void computeVertices() {
        final class_238 box = getExtents();
        final class_243[] vertices = getVertices(box);
        this.vertices = new class_243[8];
        final Matrix3d matrix = getMatrix();
        for (int i = 0; i < vertices.length; i++) {
            this.vertices[i] = matrix.transform(vertices[i]).method_1019(center);
        }
    }

    public static class_243[] getVertices(final class_238 box) {
        final class_243[] vertices = new class_243[8];
        int index = 0;
        final class_2350.class_2352[] axisDirections = class_2350.class_2352.values();
        for (final class_2350.class_2352 x : axisDirections) {
            for (final class_2350.class_2352 y : axisDirections) {
                for (final class_2350.class_2352 z : axisDirections) {
                    vertices[index++] = new class_243(getPoint(box, x, class_2350.class_2351.field_11048), getPoint(box, y, class_2350.class_2351.field_11052), getPoint(box, z, class_2350.class_2351.field_11051));
                }
            }
        }
        return vertices;
    }

    private static double getPoint(final class_238 box, final class_2350.class_2352 direction, final class_2350.class_2351 axis) {
        return direction == class_2350.class_2352.field_11060 ? box.method_1001(axis) : box.method_990(axis);
    }

    public boolean intersects(final class_238 other) {
        return intersects(getVertices(other));
    }

    public boolean intersects(final class_243[] otherVertices) {
        if (vertices == null)
            computeVertices();

        final class_243[] vertices1 = vertices;
        final class_243[] normals1 = getBasis();
        for (final class_243 normal : normals1) {
            if (!sat(normal, vertices1, otherVertices))
                return false;
        }
        final class_243[] normals2 = Matrix3d.IDENTITY_BASIS;
        for (final class_243 normal : normals2) {
            if (!sat(normal, vertices1, otherVertices))
                return false;
        }
        for (int i = 0; i < normals1.length; i++) {
            for (int j = i; j < normals2.length; j++) {
                final class_243 normal = cross(normals1[i], normals2[j]);
                if (!sat(normal, vertices1, otherVertices))
                    return false;
            }
        }
        return true;
    }


    private static class_243 cross(final class_243 first, final class_243 second) {
        return new class_243(first.field_1351 * second.field_1350 - first.field_1350 * second.field_1351, first.field_1350 * second.field_1352 - first.field_1352 * second.field_1350, first.field_1352 * second.field_1351 - first.field_1351 * second.field_1352);
    }

    private static boolean sat(final class_243 normal, final class_243[] vertices1, final class_243[] vertices2) {
        double min1 = Double.MAX_VALUE;
        double max1 = -Double.MAX_VALUE;
        for (final class_243 d : vertices1) {
            final double v = d.method_1026(normal);
            min1 = Math.min(min1, v);
            max1 = Math.max(max1, v);
        }
        double min2 = Double.MAX_VALUE;
        double max2 = -Double.MAX_VALUE;
        for (final class_243 vec3d : vertices2) {
            final double v = vec3d.method_1026(normal);
            min2 = Math.min(min2, v);
            max2 = Math.max(max2, v);
        }
        return min1 <= min2 && min2 <= max1 || min2 <= min1 && min1 <= max2;
    }

    public double raycast(final class_243 start, final class_243 end) {
        final Matrix3d inverse = getInverse();
        final class_243 d = inverse.transform(start.field_1352 - center.field_1352, start.field_1351 - center.field_1351, start.field_1350 - center.field_1350);
        final class_243 e = inverse.transform(end.field_1352 - center.field_1352, end.field_1351 - center.field_1351, end.field_1350 - center.field_1350);
        return raycast0(d, e);
    }

    private double raycast0(final class_243 start, final class_243 end) {
        final double d = end.field_1352 - start.field_1352;
        final double e = end.field_1351 - start.field_1351;
        final double f = end.field_1350 - start.field_1350;
        final double[] t = new double[]{1};
        final class_2350 direction = traceCollisionSide(getExtents(), start, t, d, e, f);
        if (direction != null) {
            return t[0];
        }
        return -1;
    }

    @Nullable
    private static class_2350 traceCollisionSide(final class_238 box, final class_243 intersectingVector, final double[] traceDistanceResult, final double xDelta, final double yDelta, final double zDelta) {
        class_2350 approachDirection = null;
        if (xDelta > 1.0E-7D)
            approachDirection = traceCollisionSide(traceDistanceResult, approachDirection, xDelta, yDelta, zDelta, box.field_1323, box.field_1322, box.field_1325, box.field_1321, box.field_1324, class_2350.field_11039, intersectingVector.field_1352, intersectingVector.field_1351, intersectingVector.field_1350);
        else if (xDelta < -1.0E-7D)
            approachDirection = traceCollisionSide(traceDistanceResult, approachDirection, xDelta, yDelta, zDelta, box.field_1320, box.field_1322, box.field_1325, box.field_1321, box.field_1324, class_2350.field_11034, intersectingVector.field_1352, intersectingVector.field_1351, intersectingVector.field_1350);

        if (yDelta > 1.0E-7D)
            approachDirection = traceCollisionSide(traceDistanceResult, approachDirection, yDelta, zDelta, xDelta, box.field_1322, box.field_1321, box.field_1324, box.field_1323, box.field_1320, class_2350.field_11033, intersectingVector.field_1351, intersectingVector.field_1350, intersectingVector.field_1352);
        else if (yDelta < -1.0E-7D)
            approachDirection = traceCollisionSide(traceDistanceResult, approachDirection, yDelta, zDelta, xDelta, box.field_1325, box.field_1321, box.field_1324, box.field_1323, box.field_1320, class_2350.field_11036, intersectingVector.field_1351, intersectingVector.field_1350, intersectingVector.field_1352);

        if (zDelta > 1.0E-7D)
            approachDirection = traceCollisionSide(traceDistanceResult, approachDirection, zDelta, xDelta, yDelta, box.field_1321, box.field_1323, box.field_1320, box.field_1322, box.field_1325, class_2350.field_11043, intersectingVector.field_1350, intersectingVector.field_1352, intersectingVector.field_1351);
        else if (zDelta < -1.0E-7D)
            approachDirection = traceCollisionSide(traceDistanceResult, approachDirection, zDelta, xDelta, yDelta, box.field_1324, box.field_1323, box.field_1320, box.field_1322, box.field_1325, class_2350.field_11035, intersectingVector.field_1350, intersectingVector.field_1352, intersectingVector.field_1351);

        return approachDirection;
    }

    @Nullable
    private static class_2350 traceCollisionSide(final double[] traceDistanceResult, final class_2350 approachDirection, final double xDelta, final double yDelta, final double zDelta, final double begin, final double minX, final double maxX, final double minZ, final double maxZ, final class_2350 resultDirection, final double startX, final double startY, final double startZ) {
        final double d = (begin - startX) / xDelta;
        final double e = startY + d * yDelta;
        final double f = startZ + d * zDelta;
        if (0.0D < d && d < traceDistanceResult[0] && minX - 1.0E-7D < e && e < maxX + 1.0E-7D && minZ - 1.0E-7D < f && f < maxZ + 1.0E-7D) {
            traceDistanceResult[0] = d;
            return resultDirection;
        } else
            return approachDirection;
    }

    public boolean contains(double x, double y, double z) {
        x -= center.field_1352;
        y -= center.field_1351;
        z -= center.field_1350;
        final double transX = getMatrix().transformX(x, y, z);
        final double transY = getMatrix().transformY(x, y, z);
        final double transZ = getMatrix().transformZ(x, y, z);
        return getExtents().method_1008(transX, transY, transZ);
    }

    public double getMax(final class_2350.class_2351 axis) {
        final Matrix3d matrix = getMatrix();
        return switch (axis) {
            case field_11048 -> Math.max(matrix.m00, Math.max(matrix.m01, matrix.m02)) * halfExtents.field_1352 + center.field_1352;
            case field_11052 -> Math.max(matrix.m10, Math.max(matrix.m11, matrix.m12)) * halfExtents.field_1351 + center.field_1351;
            case field_11051 -> Math.max(matrix.m20, Math.max(matrix.m21, matrix.m22)) * halfExtents.field_1350 + center.field_1350;
        };
    }

    public double getMin(final class_2350.class_2351 axis) {
        final Matrix3d matrix = getMatrix();
        return switch (axis) {
            case field_11048 -> Math.min(matrix.m00, Math.min(matrix.m01, matrix.m02)) * halfExtents.field_1352 + center.field_1352;
            case field_11052 -> Math.min(matrix.m10, Math.min(matrix.m11, matrix.m12)) * halfExtents.field_1351 + center.field_1351;
            case field_11051 -> Math.min(matrix.m20, Math.min(matrix.m21, matrix.m22)) * halfExtents.field_1350 + center.field_1350;
        };
    }

    public OrientedBox expand(double x, double y, double z) {
        if(x==0&&y==0&&z==0) {
            return this;
        }
        return new OrientedBox(center, halfExtents.method_1031(x/2,y/2,z/2), rotation, matrix, inverse, basis);
    }
}
