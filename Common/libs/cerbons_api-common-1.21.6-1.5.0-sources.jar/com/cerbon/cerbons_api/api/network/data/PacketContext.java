package com.cerbon.cerbons_api.api.network.data;

import net.minecraft.class_3222;

public record PacketContext<T>(class_3222 sender, T message, Side side) {

    public PacketContext(T message, Side side) {
        this(null, message, side);
    }
}
