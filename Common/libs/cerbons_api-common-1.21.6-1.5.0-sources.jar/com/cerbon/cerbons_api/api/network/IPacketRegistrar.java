package com.cerbon.cerbons_api.api.network;

import com.cerbon.cerbons_api.api.network.data.PacketContext;
import com.cerbon.cerbons_api.api.network.data.Side;
import java.util.function.Consumer;
import net.minecraft.class_2540;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

public interface IPacketRegistrar {

    /**
     * @return the side
     */
    Side getSide();

    /**
     * Packet Registration
     *
     * @param type        - The packet type.
     * @param packetClass - The class of the packet.
     * @param codec       - The StreamCodec.
     * @param handler     - The handler method.
     * @param <T>         - The class type
     * @return The registrar for chaining registrations.
     */
    <T> IPacketRegistrar registerPacket(class_8710.class_9154<? extends class_8710> type, Class<T> packetClass, class_9139<? extends class_2540, T> codec, Consumer<PacketContext<T>> handler);
}
