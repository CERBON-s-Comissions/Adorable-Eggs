package com.cerbon.cerbons_api.api.network.data;

import net.minecraft.class_8710;
import org.jetbrains.annotations.NotNull;

public record CommonPacketWrapper<T>(PacketContainer<T> container, T packet) implements class_8710 {

    @Override
    public @NotNull class_9154<? extends class_8710> method_56479() {
        return container.type();
    }
}
