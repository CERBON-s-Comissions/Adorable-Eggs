package com.cerbon.cerbons_api.api.network;

import com.cerbon.cerbons_api.api.network.data.PacketContext;
import java.util.function.Consumer;
import net.minecraft.class_2540;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

public record CommonNetwork(PacketRegistrationHandler packetRegistration) {
    private static DelayedPacketRegistrationHandler delayedHandler;
    public static CommonNetwork INSTANCE;

    public CommonNetwork(PacketRegistrationHandler packetRegistration) {
        INSTANCE = this;
        this.packetRegistration = packetRegistration;
        getDelayedHandler().registerQueuedPackets(packetRegistration);
    }

    /**
     * Fabric does not enforce load order, so we may have to delay packet registrations.
     *
     * @return the handler;
     */
    private static DelayedPacketRegistrationHandler getDelayedHandler() {
        if (delayedHandler == null)
            delayedHandler = new DelayedPacketRegistrationHandler();

        return delayedHandler;
    }

    public static <T> IPacketRegistrar registerPacket(class_8710.class_9154<? extends class_8710> type, Class<T> packetClass, class_9139<? extends class_2540, T> codec, Consumer<PacketContext<T>> handler) {
        if (INSTANCE != null) {
            return INSTANCE.packetRegistration.registerPacket(type, packetClass, codec, handler);
        }
        else
            return getDelayedHandler().registerPacket(type, packetClass, codec, handler);
    }
}
