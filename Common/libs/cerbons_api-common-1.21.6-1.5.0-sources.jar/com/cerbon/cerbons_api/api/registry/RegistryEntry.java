package com.cerbon.cerbons_api.api.registry;

import java.util.function.Supplier;
import net.minecraft.class_2960;

public interface RegistryEntry<T> extends Supplier<T> {

    @Override
    T get();

    class_2960 getId();
}
