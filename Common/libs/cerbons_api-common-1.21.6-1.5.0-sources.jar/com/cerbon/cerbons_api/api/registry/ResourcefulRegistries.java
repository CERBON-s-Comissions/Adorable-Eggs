package com.cerbon.cerbons_api.api.registry;

import com.cerbon.cerbons_api.platform.Services;
import net.minecraft.class_2378;

public class ResourcefulRegistries {

    public static <T> ResourcefulRegistry<T> create(class_2378<T> registry, String id) {
        return Services.PLATFORM_REGISTRY.create(registry, id);
    }
}
