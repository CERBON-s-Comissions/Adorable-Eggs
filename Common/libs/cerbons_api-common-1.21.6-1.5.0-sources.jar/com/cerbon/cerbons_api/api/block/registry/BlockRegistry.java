package com.cerbon.cerbons_api.api.block.registry;

import com.cerbon.cerbons_api.api.item.registry.ItemRegistry;
import com.cerbon.cerbons_api.api.registry.RegistryEntry;
import com.cerbon.cerbons_api.api.registry.ResourcefulRegistries;
import com.cerbon.cerbons_api.api.registry.ResourcefulRegistry;
import com.google.common.base.Suppliers;
import java.util.Collection;
import java.util.function.Supplier;
import java.util.stream.Stream;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class BlockRegistry {
    private final String modId;

    private final ResourcefulRegistry<class_2248> blockRegistry;
    private final Supplier<ItemRegistry> itemRegistry;

    private boolean registerItemRegistry = false;

    public BlockRegistry(String modId) {
        this(modId, Suppliers.memoize(() -> new ItemRegistry(modId)));
        this.registerItemRegistry = true;
    }

    public BlockRegistry(String modId, Supplier<ItemRegistry> itemRegistry) {
        this.modId = modId;
        this.blockRegistry = ResourcefulRegistries.create(class_7923.field_41175, modId);
        this.itemRegistry = itemRegistry;
    }

    public RegistryEntry<class_2248> registerBlockWithItem(String id) {
        return registerBlockWithItem(class_4970.class_2251.method_9637(), id);
    }

    public RegistryEntry<class_2248> registerBlockWithItem(class_4970.class_2251 blockProperties, String id) {
        return registerBlockWithItem(blockProperties, new class_1792.class_1793(), id);
    }

    public RegistryEntry<class_2248> registerBlockWithItem(class_4970.class_2251 blockProperties, class_1792.class_1793 itemProperties, String id) {
        Supplier<class_2248> block = () -> new class_2248(blockProperties.method_63500(makeId(id)));
        RegistryEntry<class_2248> blockEntry = registerBlock(block, id);
        itemRegistry.get().registerBlockItem(blockEntry, itemProperties, id);
        return blockEntry;
    }

    public RegistryEntry<class_2248> registerBlockWithItem(Supplier<class_2248> block, class_1792.class_1793 itemProperties, String id) {
        RegistryEntry<class_2248> blockEntry = registerBlock(block, id);
        itemRegistry.get().registerBlockItem(blockEntry, itemProperties, id);
        return blockEntry;
    }

    public RegistryEntry<class_2248> registerBlockWithItem(Supplier<class_2248> block, String id) {
        RegistryEntry<class_2248> blockEntry = registerBlock(block, id);
        itemRegistry.get().registerBlockItem(blockEntry, id);
        return blockEntry;
    }

    public RegistryEntry<class_2248> registerBlock(String id) {
        return registerBlock(class_4970.class_2251.method_9637(), id);
    }

    public RegistryEntry<class_2248> registerBlock(class_2248.Properties blockProperties, String id) {
        return registerBlock(() -> new class_2248(blockProperties.method_63500(makeId(id))), id);
    }

    public <T extends class_2248> RegistryEntry<T> registerBlock(Supplier<T> block, String id) {
        return blockRegistry.register(id, block);
    }

    public class_5321<class_2248> makeId(String id) {
        return class_5321.method_29179(class_7924.field_41254, class_2960.method_60655(modId, id));
    }

    public Collection<RegistryEntry<class_2248>> getEntries() { return blockRegistry.getEntries(); }
    public Stream<RegistryEntry<class_2248>> stream() { return blockRegistry.stream(); }
    public Stream<class_2248> boundStream() { return blockRegistry.boundStream(); }

    public void register() {
        blockRegistry.register();

        if (registerItemRegistry)
            itemRegistry.get().register();
    }
}
