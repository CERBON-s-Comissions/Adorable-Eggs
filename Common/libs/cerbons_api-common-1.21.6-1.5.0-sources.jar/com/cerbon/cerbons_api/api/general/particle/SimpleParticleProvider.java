package com.cerbon.cerbons_api.api.general.particle;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.function.Function;
import net.minecraft.class_2400;
import net.minecraft.class_243;
import net.minecraft.class_4002;
import net.minecraft.class_638;
import net.minecraft.class_703;
import net.minecraft.class_707;

public class SimpleParticleProvider implements class_707<class_2400> {
    private final class_4002 spriteSet;
    private final Function<ParticleContext, class_703> particleProvider;

    public SimpleParticleProvider(class_4002 spriteSet, Function<ParticleContext, class_703> particleProvider) {
        this.spriteSet = spriteSet;
        this.particleProvider = particleProvider;
    }

    @Nullable
    @Override
    public class_703 createParticle(@NotNull class_2400 type, @NotNull class_638 level, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
        return particleProvider.apply(new ParticleContext(spriteSet, level, new class_243(x, y, z), new class_243(xSpeed, ySpeed, zSpeed), true));
    }
}