package com.cerbon.cerbons_api.api.general.particle;

import com.cerbon.cerbons_api.api.static_utilities.RandomUtils;
import com.cerbon.cerbons_api.api.static_utilities.VecUtils;
import org.jetbrains.annotations.NotNull;
import org.joml.Vector3f;

import java.util.function.Function;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_3999;
import net.minecraft.class_4003;
import net.minecraft.class_4184;
import net.minecraft.class_4588;

public class SimpleParticle extends class_4003 {
    private final ParticleContext particleContext;
    private final IParticleGeometry particleGeometry;
    private final boolean cycleSprites;

    private Function<SimpleParticle, Float> rotationOverride;
    private Function<SimpleParticle, class_243> velocityOverride;
    private Function<SimpleParticle, class_243> positionOverride;
    private Function<Float, Float> scaleOverride;
    private Function<Float, class_243> colorOverride;
    private Function<Float, Integer> brightnessOverride;
    private class_243 colorVariation = class_243.field_1353;

    private float prevRotation = 0f;
    private float rotation = 0f;
    public float ageRatio = 1f;

    public SimpleParticle(ParticleContext particleContext, int particleAge, IParticleGeometry particleGeometry, boolean cycleSprites, boolean doCollision) {
        super(particleContext.level(), particleContext.pos().method_10216(), particleContext.pos().method_10214(), particleContext.pos().method_10215());
        this.particleContext = particleContext;
        this.field_3847 = particleAge;
        this.particleGeometry = particleGeometry;
        this.cycleSprites = cycleSprites;
        this.field_3862 = doCollision;
        this.field_3852 = particleContext.vel().method_10216();
        this.field_3869 = particleContext.vel().method_10214();
        this.field_3850 = particleContext.vel().method_10215();

        if (cycleSprites) method_18142(particleContext.spriteSet());
        else method_18141(particleContext.spriteSet().method_18139(this.field_3840));
    }

    @Override
    public @NotNull class_3999 method_18122() {
        return class_3999.field_17828;
    }

    public @NotNull class_243 getPos() {
        return new class_243(field_3874, field_3854, field_3871);
    }

    public int getAge() {
        return field_3866;
    }

    @Override
    public void method_3070() {
        super.method_3070();
        if (!method_3086()) return;

        if (cycleSprites) method_18142(particleContext.spriteSet());
        ageRatio = (float) field_3866 / field_3847;
        setColorFromOverride(colorOverride, ageRatio);
        setScaleFromOverride(scaleOverride, ageRatio);
        setVelocityFromOverride(velocityOverride);
        setPositionFromOverride(positionOverride);
        setRotationFromOverride(rotationOverride);

    }

    private void setRotationFromOverride(Function<SimpleParticle, Float> rotationOverride) {
        if (rotationOverride == null) return;

        float rot = rotationOverride.apply(this);
        prevRotation = rotation;
        rotation = rot;
    }

    private void setVelocityFromOverride(Function<SimpleParticle, class_243> velocityOverride) {
        if (velocityOverride == null) return;

        class_243 velocity = velocityOverride.apply(this);
        field_3852 = velocity.method_10216();
        field_3869 = velocity.method_10214();
        field_3850 = velocity.method_10215();
    }

    private void setPositionFromOverride(Function<SimpleParticle, class_243> positionOverride) {
        if (positionOverride == null) return;

        class_243 pos = positionOverride.apply(this);
        method_3063(pos.method_10216(), pos.method_10214(), pos.method_10215());
    }

    private void setScaleFromOverride(Function<Float, Float> scaleOverride, float ageRatio) {
        if (scaleOverride == null) return;

        field_17867 = scaleOverride.apply(ageRatio);
        method_3080(0.2f * field_17867, 0.2f * field_17867);
    }

    private void setColorFromOverride(Function<Float, class_243> colorOverride, float ageRatio) {
        if (colorOverride == null) return;

        class_243 color = colorOverride.apply(ageRatio);
        class_243 variedColor = VecUtils.coerceAtMost(VecUtils.coerceAtLeast(color.method_1019(colorVariation), class_243.field_1353), VecUtils.unit);
        method_3084((float) variedColor.method_10216(), (float) variedColor.method_10214(), (float) variedColor.method_10215());
    }

    public void setBrightnessOverride(Function<Float, Integer> override) {
        brightnessOverride = override;
    }

    public void setColorOverride(Function<Float, class_243> override) {
        colorOverride = override;
        setColorFromOverride(override, 0f);
    }

    public void setScaleOverride(Function<Float, Float> override) {
        scaleOverride = override;
        setScaleFromOverride(override, 0f);
    }

    public void setColorVariation(double variation) {
        colorVariation = RandomUtils.randVec().method_1021(variation);
        setColorFromOverride(colorOverride, 0f);
    }

    public void setVelocityOverride(Function<SimpleParticle, class_243> override) {
        velocityOverride = override;
    }

    public void setPositionOverride(Function<SimpleParticle, class_243> override) {
        positionOverride = override;
    }

    public void setRotationOverride(Function<SimpleParticle, Float> override) {
        rotationOverride = override;

        if (rotationOverride != null) {
            rotation = rotationOverride.apply(this);
            prevRotation = rotationOverride.apply(this);
        }
    }

    @Override
    protected int method_3068(float partialTick) {
        return brightnessOverride != null ? brightnessOverride.apply(ageRatio) : super.method_3068(partialTick);
    }

    @Override
    public void method_3074(class_4588 vertexConsumer, @NotNull class_4184 camera, float partialTicks) {
        Vector3f[] vector3fs = particleGeometry.getGeometry(
                camera,
                partialTicks,
                field_3858, field_3838, field_3856,
                field_3874, field_3854, field_3871,
                method_18132(partialTicks),
                class_3532.method_16439(partialTicks, prevRotation, rotation)
        );

        float l = this.method_18133();
        float m = this.method_18134();
        float n = this.method_18135();
        float o = this.method_18136();
        float p = method_3068(partialTicks);

        vertexConsumer.method_22912(
                vector3fs[0].x(), vector3fs[0].y(),
                vector3fs[0].z()
        ).method_22913(m, o).method_22915(field_3861, field_3842, field_3859, field_3841).method_60803((int) p);

        vertexConsumer.method_22912(
                vector3fs[1].x(), vector3fs[1].y(),
                vector3fs[1].z()
        ).method_22913(m, n).method_22915(field_3861, field_3842, field_3859, field_3841).method_60803((int) p);

        vertexConsumer.method_22912(
                vector3fs[2].x(), vector3fs[2].y(),
                vector3fs[2].z()
        ).method_22913(l, n).method_22915(field_3861, field_3842, field_3859, field_3841).method_60803((int) p);

        vertexConsumer.method_22912(
                vector3fs[3].x(), vector3fs[3].y(),
                vector3fs[3].z()
        ).method_22913(l, o).method_22915(field_3861, field_3842, field_3859, field_3841).method_60803((int) p);
    }
}