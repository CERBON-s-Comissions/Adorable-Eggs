package com.cerbon.cerbons_api.api.general.particle;

import net.minecraft.class_243;
import net.minecraft.class_4002;
import net.minecraft.class_638;

public record ParticleContext(
        class_4002 spriteSet,
        class_638 level,
        class_243 pos,
        class_243 vel,
        Boolean cycleSprites
    ) {
}