package com.cerbon.cerbons_api.api.general.math;

import com.cerbon.cerbons_api.api.static_utilities.VecUtils;
import net.minecraft.class_243;

public class ReferencedAxisRotator {
    private final double angleBetween;
    private final class_243 rotationAxis;

    public ReferencedAxisRotator(class_243 originalAxis, class_243 newAxis) {
        this.angleBetween = VecUtils.unsignedAngle(originalAxis, newAxis);
        this.rotationAxis = originalAxis.method_1036(newAxis);
    }

    public class_243 rotate(class_243 vec) {
        return VecUtils.rotateVector(vec, rotationAxis, angleBetween);
    }
}
