package com.cerbon.cerbons_api.api.static_utilities;

import com.cerbon.cerbons_api.api.general.particle.ClientParticleBuilder;
import java.util.Random;
import net.minecraft.class_2394;
import net.minecraft.class_243;
import net.minecraft.class_3218;

public class ParticleUtils {

    public static void spawnParticle(class_3218 level, class_2394 particleType, class_243 pos, class_243 velOrOffset, int count, double speed) {
        level.method_65096(particleType, pos.field_1352, pos.field_1351, pos.field_1350, count, velOrOffset.field_1352, velOrOffset.field_1351, velOrOffset.field_1350, speed);
    }

    public static void spawnRotatingParticles(RotatingParticles particleParams) {
        int startingRotation = new Random().nextInt(360);
        double randomRadius = RandomUtils.range(particleParams.minRadius(), particleParams.maxRadius());
        double rotationSpeed = RandomUtils.range(particleParams.minSpeed(), particleParams.maxSpeed());
        ClientParticleBuilder particleBuilder = particleParams.particleBuilder();
        particleBuilder
                .continuousPosition(simpleParticle -> rotateAroundPos(particleParams.pos(), simpleParticle.getAge(), startingRotation, randomRadius, rotationSpeed))
                .build(rotateAroundPos(particleParams.pos(), 0, startingRotation, randomRadius, rotationSpeed), class_243.field_1353);
    }

    private static class_243 rotateAroundPos(class_243 pos, int age, int startingRotation, double radius, double rotationSpeed) {
        class_243 xzOffset = VecUtils.xAxis.method_1024((float)Math.toRadians(age * rotationSpeed + startingRotation));
        return pos.method_1019(xzOffset.method_1021(radius));
    }

    public record RotatingParticles(class_243 pos, ClientParticleBuilder particleBuilder, double minRadius, double maxRadius, double minSpeed, double maxSpeed) {}
}