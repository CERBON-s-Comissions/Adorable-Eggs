package com.cerbon.cerbons_api.api.static_utilities;

import net.minecraft.class_1267;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_243;

public class MobUtils {
    public static void setPos(class_1297 entity, class_243 vec) {
        entity.method_30634(vec.field_1352, vec.field_1351, vec.field_1350);
    }

    public static class_243 eyePos(class_1297 entity) {
        return entity.method_5836(1.0f);
    }

    public static class_243 lastRenderPos(class_1297 entity) {
        return new class_243(entity.field_6038, entity.field_5971, entity.field_5989);
    }

    public static void preventDespawnExceptPeaceful(class_1309 mobEntity, class_1937 level) {
        if (level.method_8407() == class_1267.field_5801) mobEntity.method_31472();
        else mobEntity.method_16826(0);
    }
}
