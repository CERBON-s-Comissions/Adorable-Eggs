package com.cerbon.cerbons_api.api.static_utilities;

import net.minecraft.class_243;

public class Vec3Colors {
    private static final double colorFactor = 1 / 255.0;
    public static final class_243 WHITE = VecUtils.unit;
    public static final class_243 COMET_BLUE = new class_243(0.0, 1.0, 1.0);
    public static final class_243 FADED_COMET_BLUE = new class_243(0.0, 0.3, 0.3);
    public static final class_243 TELEPORT_PURPLE = new class_243(1.0, 0.5, 1.0);
    public static final class_243 ORANGE = new class_243(1.0, 0.65, 0.1);
    public static final class_243 RUNIC_BROWN = new class_243(0.66, 0.34, 0.0);
    public static final class_243 RED = new class_243(0.8, 0.2, 0.4);
    public static final class_243 DARK_RED = new class_243(0.4, 0.0, 0.0);
    public static final class_243 ENDER_PURPLE = new class_243(158 / 255.0, 66 / 255.0, 245 / 255.0);
    public static final class_243 VOID_PURPLE = new class_243(0.7, 0.3, 0.6);
    public static final class_243 LASER_RED = new class_243(0.8, 0.1, 0.1);
    public static final class_243 GREY = VecUtils.unit.method_1021(0.5);
    public static final class_243 GREEN = new class_243(0.3, 0.8, 0.3);
    public static final class_243 DARK_GREEN = new class_243(0.0, 0.5, 0.1);
    public static final class_243 PINK = new class_243(0.9, 0.6, 0.8);
    public static final class_243 ULTRA_DARK_PURPLE = new class_243(0.3, 0.0, 0.2);
    public static final class_243 DARK_GREY = new class_243(0.3, 0.3, 0.3);
    public static final class_243 LIGHT_ENDER_PEARL = new class_243(140.0, 244.0, 226.0).method_1021(colorFactor);
    public static final class_243 DARK_ENDER_PEARL = new class_243(3.0, 38.0, 32.0).method_1021(colorFactor);
    public static final class_243 GOLD = new class_243(255.0, 211.0, 125.0).method_1021(colorFactor);
}
