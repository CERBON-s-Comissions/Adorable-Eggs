package com.cerbon.cerbons_api.api.static_utilities;

import com.cerbon.cerbons_api.platform.Services;
import com.cerbon.cerbons_api.platform.services.IMenuTypeHelper;
import java.util.function.Consumer;
import java.util.function.Function;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_2540;
import net.minecraft.class_3222;
import net.minecraft.class_3908;
import net.minecraft.class_3917;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public class MenuTypeUtils {

    public static <T extends class_1703> class_3917<T> registerSimpleMenuType(IMenuTypeHelper.SimpleMenuSupplier<T> factory) {
        return Services.PLATFORM_MENU_TYPE.registerSimpleMenuType(factory);
    }

    public static <T extends class_1703, D> class_3917<T> registerExtendedMenuType(IMenuTypeHelper.ExtendedMenuSupplier<T, D> factory, class_9139<? super class_9129, D> extraDataFabric) {
        return Services.PLATFORM_MENU_TYPE.registerExtendedMenuType(factory, extraDataFabric);
    }

    public static <D> void openExtendedMenu(class_1657 player, class_3908 menuProvider, Function<class_3222, D> extraDataFabric, Consumer<class_2540> extraDataForge) {
        Services.PLATFORM_MENU_TYPE.openExtendedMenu(player, menuProvider, extraDataFabric, extraDataForge);
    }
}
