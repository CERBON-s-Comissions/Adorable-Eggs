package com.cerbon.cerbons_api.api.static_utilities;

import net.minecraft.class_2338;
import net.minecraft.class_243;

public class VecUtils {
    public static final class_243 xAxis = new class_243(1.0, 0.0, 0.0);
    public static final class_243 yAxis = new class_243(0.0, 1.0, 0.0);
    public static final class_243 zAxis = new class_243(0.0, 0.0, 1.0);
    public static final class_243 unit = new class_243(1.0, 1.0, 1.0);

    public static class_243 yOffset(class_243 vec, double i) {
        return vec.method_1031(0.0, i, 0.0);
    }

    public static class_243 planeProject(class_243 vec, class_243 planeVector) {
        return vec.method_1020(planeVector.method_1021(vec.method_1026(planeVector)));
    }

    public static class_243 asVec3(class_2338 blockPos) {
        return new class_243(blockPos.method_10263(), blockPos.method_10264(), blockPos.method_10260());
    }

    public static class_243 negateServer(class_243 vec) {
        return vec.method_1021(-1.0);
    }

    public static class_243 coerceAtLeast(class_243 vec1, class_243 vec2) {
        return new class_243(Math.max(vec1.method_10216(), vec2.method_10216()), Math.max(vec1.method_10214(), vec2.method_10214()), Math.max(vec1.method_10215(), vec2.method_10215()));
    }

    public static class_243 coerceAtMost(class_243 vec1, class_243 vec2) {
        return new class_243(Math.min(vec1.method_10216(), vec2.method_10216()), Math.min(vec1.method_10214(), vec2.method_10214()), Math.min(vec1.method_10215(), vec2.method_10215()));
    }

    // http://www.java-gaming.org/index.php/topic,28253
    // https://www.omnicalculator.com/math/angle-between-two-vectors#angle-between-two-vectors-formulas
    public static double unsignedAngle(class_243 vec, class_243 b) {
        double dot = vec.method_1026(b);
        double lengths = vec.method_1033() * b.method_1033();

        if (lengths == 0.0)
            return 0.0;

        double cos = Math.max(-1.0, Math.min(1.0, dot / lengths));
        return Math.toDegrees(Math.acos(cos));
    }

    /**
     * Rotate a vector around an axis by given degrees <a href="https://stackoverflow.com/questions/31225062/rotating-a-vector-by-angle-and-axis-in-java">Rotating a vector by angle and axis - StackOverflow</a>
     */
    public static class_243 rotateVector(class_243 vec, class_243 axis, double degrees) {
        double theta = Math.toRadians(degrees);
        class_243 normedAxis = axis.method_1029();
        double x = vec.method_10216();
        double y = vec.method_10214();
        double z = vec.method_10215();
        double u = normedAxis.method_10216();
        double v = normedAxis.method_10214();
        double w = normedAxis.method_10215();
        double v1 = u * x + v * y + w * z;
        double xPrime = u * v1 * (1.0 - Math.cos(theta)) + x * Math.cos(theta) + (-w * y + v * z) * Math.sin(theta);
        double yPrime = v * v1 * (1.0 - Math.cos(theta)) + y * Math.cos(theta) + (w * x - u * z) * Math.sin(theta);
        double zPrime = w * v1 * (1.0 - Math.cos(theta)) + z * Math.cos(theta) + (-v * x + u * y) * Math.sin(theta);
        return new class_243(xPrime, yPrime, zPrime);
    }
}
