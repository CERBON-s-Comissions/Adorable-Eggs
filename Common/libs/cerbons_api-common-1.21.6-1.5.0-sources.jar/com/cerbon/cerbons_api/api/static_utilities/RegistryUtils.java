package com.cerbon.cerbons_api.api.static_utilities;

import net.minecraft.class_1291;
import net.minecraft.class_1299;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_3195;
import net.minecraft.class_3218;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import org.jetbrains.annotations.NotNull;

public class RegistryUtils {

    public static class_2248 getBlockByKey(String key) {
        return class_7923.field_41175.method_63535(class_2960.method_12829(key));
    }

    public static class_1792 getItemByKey(String key) {
        return class_7923.field_41178.method_63535(class_2960.method_12829(key));
    }

    public static @NotNull String getItemKeyAsString(class_1792 item) {
        return class_7923.field_41178.method_10221(item).toString();
    }

    public static class_1291 getMobEffectByKey(String key) {
        return class_7923.field_41174.method_63535(class_2960.method_12829(key));
    }

    public static class_1299<?> getEntityTypeByKey(String key) {
        return class_7923.field_41177.method_63535(class_2960.method_12829(key));
    }

    public static class_3195 getStructureByKey(String key, class_3218 serverLevel) {
        return serverLevel.method_30349().method_30530(class_7924.field_41246).method_63535(class_2960.method_12829(key));
    }
}
