package com.cerbon.cerbons_api.api.static_utilities;

import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import net.minecraft.class_7833;
import org.jetbrains.annotations.NotNull;
import org.joml.Quaternionf;
import org.joml.Vector3f;

public class Geometries {

    public static Vector3f[] buildBillBoardGeometry(
            @NotNull class_4184 camera,
            float tickDelta,
            double prevPosX,
            double prevPosY,
            double prevPosZ,
            double x,
            double y,
            double z,
            float scale,
            float rotation
    ) {
        class_243 vec3 = camera.method_19326();
        float f = (float) (class_3532.method_16436(tickDelta, prevPosX, x) - vec3.method_10216());
        float g = (float) (class_3532.method_16436(tickDelta, prevPosY, y) - vec3.method_10214());
        float h = (float) (class_3532.method_16436(tickDelta, prevPosZ, z) - vec3.method_10215());
        Quaternionf quaternion2 = camera.method_23767();

        Vector3f[] vector3fs = {
                new Vector3f(1.0f, -1.0f, 0.0f),
                new Vector3f(1.0f, 1.0f, 0.0f),
                new Vector3f(-1.0f, 1.0f, 0.0f),
                new Vector3f(-1.0f, -1.0f, 0.0f)
        };

        for (int k = 0; k <= 3; k++) {
            Vector3f vector3f2 = vector3fs[k];
            vector3f2.rotate(class_7833.field_40718.rotationDegrees(rotation));
            vector3f2.rotate(quaternion2);
            vector3f2.mul(scale);
            vector3f2.add(f, g, h);
        }

        return vector3fs;
    }

    public static Vector3f @NotNull [] buildFlatGeometry(
            @NotNull class_4184 camera,
            float tickDelta,
            double prevPosX,
            double prevPosY,
            double prevPosZ,
            double x,
            double y,
            double z,
            float scale,
            float rotation
    ) {
        class_243 vec3 = camera.method_19326();
        float f = (float) (class_3532.method_16436(tickDelta, prevPosX, x) - vec3.method_10216());
        float g = (float) (class_3532.method_16436(tickDelta, prevPosY, y) - vec3.method_10214());
        float h = (float) (class_3532.method_16436(tickDelta, prevPosZ, z) - vec3.method_10215());

        Vector3f[] vector3fs = new Vector3f[] {
                new Vector3f(-1.0f, 0.0f, -1.0f),
                new Vector3f(-1.0f, 0.0f, 1.0f),
                new Vector3f(1.0f, 0.0f, 1.0f),
                new Vector3f(1.0f, 0.0f, -1.0f)
        };

        for (int k = 0; k <= 3; k++) {
            Vector3f vector3f2 = vector3fs[k];
            vector3f2.rotate(class_7833.field_40716.rotationDegrees(rotation));
            vector3f2.mul(scale);
            vector3f2.add(f, g, h);
        }

        return vector3fs;
    }
}
