package com.cerbon.cerbons_api.api.static_utilities;

import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_2767;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_5819;
import net.minecraft.class_6880;
import org.jetbrains.annotations.NotNull;

public class SoundUtils {

    public static void playSound(class_3218 level, class_243 pos, class_3414 soundEvent, class_3419 soundSource, float volume, double range) {
        playSound(level, pos, soundEvent, soundSource, volume, range, null);
    }

    public static void playSound(class_3218 level, class_243 pos, class_3414 soundEvent, class_3419 soundSource, float volume, double range, class_1657 except) {
        playSound(level, pos, soundEvent, soundSource, volume, randomPitch(level.field_9229), range, except);
    }

    public static void playSound(class_3218 level, class_243 pos, class_3414 soundEvent, class_3419 soundSource, float volume, float pitch, double range, class_1657 except) {
        class_6880<class_3414> holder = class_6880.method_40223(class_3414.method_47908(soundEvent.comp_3319()));
        level.method_8503().method_3760().method_14605(
                except,
                pos.field_1352,
                pos.field_1351,
                pos.field_1350,
                range,
                level.method_27983(),
                new class_2767(holder, soundSource, pos.field_1352, pos.field_1351, pos.field_1350, volume, pitch, level.field_9229.method_43055())
        );
    }

    public static float randomPitch(@NotNull class_5819 random) {
        return (random.method_43057() - random.method_43057()) * 0.2f + 1.0f;
    }
}
