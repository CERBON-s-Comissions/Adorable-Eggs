package com.cerbon.cerbons_api.api.static_utilities;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import net.minecraft.class_243;
import net.minecraft.class_2540;

public class PacketUtils {
    public static List<Float> readFloatList(class_2540 buf, int count) {
        if (count < 0) throw new IllegalArgumentException("Count should be greater than zero");

        List<Float> list = new ArrayList<>();
        for (int i = 0; i < count; i++)
            list.add(buf.readFloat());

        return list;
    }

    public static void writeFloatList(class_2540 buf, List<Float> list) {
        for (Float f : list)
            buf.method_52941(f);
    }

    public static void writeVec3(class_2540 buf, class_243 vec) {
        writeFloatList(buf, Arrays.asList((float) vec.field_1352, (float) vec.field_1351, (float) vec.field_1350));
    }

    public static class_243 readVec3(class_2540 buf) {
        List<Float> floatList = readFloatList(buf, 3);
        return new class_243(floatList.get(0), floatList.get(1), floatList.get(2));
    }
}
